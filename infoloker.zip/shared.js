const JOBS_API = '/api/jobs/list.php';
const JOB_DETAIL_API = '/api/jobs/detail.php';

const CAT_ICONS = [
  'IT', 'Design', 'Marketing', 'Data',
  'Finance', 'Management', 'HR',
  'Operations', 'Support'
];

function esc(s) {
  return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

function shuffle(arr) {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

function logoSlug(company) {
  return String(company).toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
}

function logoPath(company) {
  return `./assets/logos/${logoSlug(company)}.png`;
}

function logoImg(company, cls, fbCls) {
  return `
    <img src="${logoPath(company)}" alt="${esc(company)}" class="${cls}"
    onerror="this.onerror=null; this.replaceWith(createFallback('${esc(company)}','${fbCls}'))">
  `;
}

function createFallback(company, fbCls) {
  const div = document.createElement('div');
  div.className = fbCls;
  div.textContent = company[0];
  return div;
}

function fmtDate(s) {
  return new Date(s).toLocaleDateString('id-ID', { day: 'numeric', month: 'short', year: 'numeric' });
}

function fmtDateLong(s) {
  return new Date(s).toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' });
}

function daysAgo(dateStr) {
  const diff = Math.floor((Date.now() - new Date(dateStr)) / 86400000);
  if (diff === 0) return 'Hari ini';
  if (diff === 1) return 'Kemarin';
  return `${diff} hari lalu`;
}

async function fetchJobs() {
  const r = await fetch(JOBS_API, { cache: 'no-store', credentials: 'same-origin' });
  const body = await r.json().catch(() => null);
  if (!r.ok || !body || body.success === false) {
    throw new Error((body && body.error) || `HTTP ${r.status}`);
  }
  if (!Array.isArray(body.data)) throw new Error('Format data tidak valid');
  return body.data;
}

async function fetchJob(id) {
  const r = await fetch(`${JOB_DETAIL_API}?id=${encodeURIComponent(id)}`, {
    cache: 'no-store', credentials: 'same-origin'
  });
  const body = await r.json().catch(() => null);
  if (!r.ok || !body || body.success === false) {
    throw new Error((body && body.error) || `HTTP ${r.status}`);
  }
  return body.data;
}
